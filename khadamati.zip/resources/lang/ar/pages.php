<?php

return [

    'terms_and_conditions' => 'الشروط و الاحكام',
    'terms_and_conditions_ar' => 'الشروط و الاحكام بالعربية',
    'terms_and_conditions_en' => 'الشروط و الاحكام بالانجليزية',
    'privacy_policy_en' => 'سياية الخصوصية بالانجليزية',
    'privacy_policy_ar' => 'سياية الخصوصية بالعربية',
];

<?php

return [

    'title' => 'ادارة الطلبات',
    'delete' => 'حذف تصنيف',
    'image' => 'الصورة',
    'pending' => 'الانتظار',
    'current' => 'الحالية',
    'rejected' => 'ملغاه',
    'completed' => 'مكتملة',
    'user' => 'المستخدم',
    'worker' => 'الحرفي',
    'subCategory' => 'التصنيف الفرعي',
    'states' => 'الحالة',
    'show' => 'عرض',
    'time_type' => 'نوع الوقت',
    'longitude' => 'الخط الطولي',
    'latitude' => 'الخط العرضي',
    'image_chose' => 'اختر صورة الطلب',
    'description' => 'التفاصيل',
    'date' => 'التاريخ',

];

<?php

return [

    'admin_title' => 'ادارة المدراء',
    'admin_add' => 'اضافة المدير',
    'admin_edit' => 'تعديل المدير',
    'profile_edit' => 'تعديل الملف الشخصي',
    'admin_delete' => 'حذف المدير',
    'admin_name' => 'ادخل اسم المدير',
    'admin_email' => 'ادخل البريد الالكتروني',
    'admin_password' => 'ادخل كلمة المرور',
];

<?php

return [

    'role' => 'الصلاحيات',
    'dashboard' => 'الصفحة الرئسية',
    'admin' => 'المدراء',
    'city' => 'المدن',
    'day' => 'الايام',
    'category' => 'التصنيفات',
    'sub_category' => 'التصنيفات الفرعية',
    'user' => 'المستخدمين',
    'worker' => 'الحرفيين',
    'slider' => 'سلايدر',
    'order' => 'الطلبات',
    'pages' => 'الصفحات',
    'terms_and_conditions' => 'الشروط و الاحكام',
    'privacy_policy' => 'سياسة الخصوصية',
    'contacts' => 'اتصل بنا',
];

<?php

return [

    'role_title' => 'ادارة الصلاحيات',
    'role_Add' => 'اضافة صلاحية',
    'role_edit' => 'تعديل صلاحية',
    'delete_role' => 'حذف الصلاحية',
    'name_role' => 'ادخل اسم الصلاحية',
    'permissions' => 'الاذونات',
];

<?php

return [

    'city_title' => 'ادارة المدن',
    'city_add' => 'اضافة مدينة',
    'city_edit' => 'تعديل مدينة',
    'city_delete' => 'حذف مدينة',
    'city_name_ar' => 'ادخل اسم المدينة بالعربية',
    'city_name_en' => 'ادخل اسم المدينة بالانجليزية',
];

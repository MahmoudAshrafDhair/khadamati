<?php

return [

    'role_title' => 'Role Management',
    'role_Add' => 'Add Role',
    'role_edit' => 'Role Edit',
    'delete_role' => 'Delete Role',
    'name_role' => 'Enter Your Role Name',
    'permissions' => 'Permissions',
];

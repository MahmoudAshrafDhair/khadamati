<?php

return [

    'title' => 'Workers Management',
    'add' => 'Add Worker',
    'edit' => 'Edit Worker',
    'delete' => 'Delete Worker',
    'image' => 'Image',
    'username' => 'Username',
    'phone' => 'Phone Number',
    'email' => 'Email',
    'password' => 'Password',
    'city' => 'City',
    'service' => 'Service',
    'image_user' => 'Choose The Image Of User',
];

<?php

return [

    'title' => 'Orders Management',
    'delete' => 'Delete Order',
    'image' => 'Image',
    'pending' => 'Pending',
    'current' => 'Current',
    'rejected' => 'Rejected',
    'completed' => 'Completed',
    'user' => 'User',
    'worker' => 'Worker',
    'subCategory' => 'SubCategory',
    'states' => 'States',
    'show' => 'Show',
    'time_type' => 'Time Type',
    'longitude' => 'Longitude',
    'latitude' => 'Latitude',
    'image_chose' => 'Chose Order Image',
    'description' => 'Description',
    'date' => 'Date',
];

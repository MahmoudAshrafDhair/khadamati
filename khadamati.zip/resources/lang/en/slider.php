<?php

return [

    'title' => 'Sliders Management',
    'add' => 'Add Slider',
    'edit' => 'Edit Slider',
    'delete' => 'Delete Slider',
    'image' => 'Image',
    'image_slider' => 'Choose The Image Of Slider',
];

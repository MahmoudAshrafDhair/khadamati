<?php

return [

    'title' => 'Categories Management',
    'add' => 'Add Category',
    'edit' => 'Edit Category',
    'delete' => 'Delete Category',
    'image' => 'Image',
    'category' => 'Category',
    'name_ar' => 'Enter the name of the Category in Arabic',
    'name_en' => 'Enter the name of the Category in English',
    'image_category' => 'Choose The Image Of Category',
];

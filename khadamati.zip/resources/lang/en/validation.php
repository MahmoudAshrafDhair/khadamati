<?php

return [

    'required' => 'This Field Must Be Required',
    'numeric' => 'This Field Must Be Numeric',
    'required_without' => 'This Field Must Be Required',
    'unique' => 'This text must not be repeated',
    'email' => 'This Field Must Be Email',
    'image' => 'This Field Must Be Image',
    'mimes' => 'This Field Must Be format is (jpeg,png,jpg,gif,svg)',
    'login' => 'You are not authorized to enter, please verify the data',
    'login_successfully' => 'Login Successfully',
    'confirmed' => 'Password does not match',
];

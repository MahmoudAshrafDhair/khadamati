<?php

return [

    'city_title' => 'Cities Management',
    'city_add' => 'Add City',
    'city_edit' => 'Edit City',
    'city_delete' => 'Delete City',
    'city_name_ar' => 'Enter the name of the City in Arabic',
    'city_name_en' => 'Enter the name of the City in English',
];

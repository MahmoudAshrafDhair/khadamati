<?php

return [

    'title' => 'Users Management',
    'add' => 'Add User',
    'edit' => 'Edit User',
    'delete' => 'Delete User',
    'image' => 'Image',
    'username' => 'Username',
    'phone' => 'Phone Number',
    'email' => 'Email',
    'password' => 'Password',
    'city' => 'City',
    'image_user' => 'Choose The Image Of User',
];

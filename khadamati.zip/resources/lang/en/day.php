<?php

return [

    'title' => 'Days Management',
    'add' => 'Add Day',
    'edit' => 'Edit Day',
    'delete' => 'Delete Day',
    'name_ar' => 'Enter the name of the Day in Arabic',
    'name_en' => 'Enter the name of the Day in English',
];

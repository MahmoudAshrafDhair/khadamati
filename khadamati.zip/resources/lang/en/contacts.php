<?php

return [

    'title_user' => 'User Contact Us Management',
    'title_worker' => 'Worker Contact Us Management',
    'username' => 'Username',
    'email' => 'Email',
    'message' => 'Message',
    'delete' => 'Delete',
    'show_user' => 'Show User Contact',
    'show_worker' => 'Show Worker Contact',
];

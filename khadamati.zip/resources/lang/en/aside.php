<?php

return [

    'role' => 'Roles',
    'dashboard' => 'Dashboard',
    'admin' => 'Admins',
    'city' => 'Cities',
    'day' => 'Days',
    'category' => 'Categories',
    'sub_category' => 'SubCategories',
    'user' => 'Users',
    'worker' => 'Workers',
    'slider' => 'Sliders',
    'order' => 'Orders',
    'pages' => 'Pages',
    'terms_and_conditions' => 'Terms and conditions',
    'privacy_policy' => 'Privacy Policy',
    'contacts' => 'Contact Us',
];

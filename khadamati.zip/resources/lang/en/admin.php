<?php

return [

    'admin_title' => 'Admin Management',
    'admin_add' => 'Add Admin',
    'admin_edit' => 'Edit Admin',
    'profile_edit' => 'Edit Profile',
    'admin_delete' => 'Delete Admin',
    'admin_name' => 'Enter your admin name',
    'admin_email' => 'Enter Email',
    'admin_password' => 'Enter Password',
];

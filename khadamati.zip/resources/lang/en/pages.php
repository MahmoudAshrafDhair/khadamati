<?php

return [

    'terms_and_conditions' => 'Terms And Conditions',
    'terms_and_conditions_ar' => 'Terms And Conditions In Arabic',
    'terms_and_conditions_en' => 'Terms And Conditions In English',
    'privacy_policy_en' => 'Privacy Policy In English',
    'privacy_policy_ar' => 'Privacy Policy In Arabic',
];

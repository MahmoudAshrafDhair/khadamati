@extends('dashboard.layout.master')

@section('title')

@stop

@section('style')

@stop

@section('breadcrumb')

@stop

@section('content')

@stop

@section('script')

@stop
